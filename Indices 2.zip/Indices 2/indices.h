#ifndef INDICES_H
#define INDICES_H
#include <array>
#include <vector>
#include <utility>

// function that takes int vector and int 
std::pair<int, int> getNumSums(std::vector<int> nums, int target, int test[]);

#endif
